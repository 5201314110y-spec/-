# 🚗 车载音乐 APK

竖屏车机适配的聚合音乐播放器 Android 应用。

## 项目结构

```
car-music-apk/
├── build.gradle                    # 根构建文件
├── settings.gradle
├── gradle/wrapper/
│   └── gradle-wrapper.properties
├── app/
│   ├── build.gradle                # 应用构建配置
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/carmusic/app/
│       │   └── MainActivity.java   # WebView 主活动
│       ├── res/mipmap-*/
│       │   └── ic_launcher.png     # 各密度图标
│       └── assets/www/
│           └── index.html          # 前端页面
```

## 编译方法

### 方法一：Android Studio（推荐）

1. 用 Android Studio 打开 `car-music-apk/` 目录
2. 等待 Gradle 同步完成
3. Build → Build Bundle(s) / APK(s) → Build APK(s)
4. APK 输出在 `app/build/outputs/apk/debug/app-debug.apk`

### 方法二：命令行编译

```bash
cd car-music-apk
chmod +x gradlew  # 如果有 gradlew
./gradlew assembleDebug

# 或使用系统 gradle
gradle assembleDebug
```

### 方法三：在线编译（无需本地环境）

使用 GitHub Actions：
1. 将项目推送到 GitHub
2. 添加 `.github/workflows/build.yml`（见下方）
3. Push 后自动编译，在 Actions 页面下载 APK

## GitHub Actions 配置

在项目根目录创建 `.github/workflows/build.yml`：

```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          distribution: 'temurin'
          java-version: '11'
      - name: Build Debug APK
        run: |
          chmod +x gradlew
          ./gradlew assembleDebug
      - uses: actions/upload-artifact@v3
        with:
          name: car-music-debug
          path: app/build/outputs/apk/debug/app-debug.apk
```

## 安装到车机

```bash
# USB 连接车机后
adb install app-debug.apk

# 或拷贝到U盘，车机文件管理器安装
```

## 功能

- 聚合搜索：网易云、QQ、酷狗、酷我、咪咕、B站
- 竖屏全屏：适配竖屏车机，沉浸式无状态栏
- 大按钮交互：驾驶时易操作
- 歌词同步：全屏歌词浮层
- 自动连播：播完自动下一首
- 常亮屏幕：播放时不息屏

## 注意事项

- 需要网络连接（WiFi 或车载流量）
- 音频 URL 有时效性，断网后需重新搜索
- 部分歌曲因版权限制可能无法播放
- 最低支持 Android 5.0 (API 21)
